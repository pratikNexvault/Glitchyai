"use client";
import { useState, useEffect, useRef } from "react";

/* ── PASSWORD (only non-secret stored locally) ── */
const PW_KEY = "lumis_pw";
const getPw = () => { try { return localStorage.getItem(PW_KEY) || "lumis2024"; } catch { return "lumis2024"; } };
const setPw = (p: string) => { try { localStorage.setItem(PW_KEY, p); } catch {} };

/* ── SESSION ID ── */
const getSession = () => { try { let s = sessionStorage.getItem("lumis_sid"); if (!s) { s = "web_" + Date.now(); sessionStorage.setItem("lumis_sid", s); } return s; } catch { return "web_" + Date.now(); } };

/* ── LOCAL MEMORY (fallback when no MongoDB) ── */
const MEM_KEY = "lumis_mem";
const getLocalMem = () => { try { return JSON.parse(localStorage.getItem(MEM_KEY) || "[]"); } catch { return []; } };
const addLocalMem = (text: string, type = "fact") => {
  const m = getLocalMem();
  m.push({ id: Date.now().toString(), text, type, ts: new Date().toISOString() });
  try { localStorage.setItem(MEM_KEY, JSON.stringify(m.slice(-200))); } catch {}
};

/* ── STYLES ── */
const CSS = `
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body,#root{width:100%;height:100%}
body{font-family:'Outfit',sans-serif;background:#f0f4f1;color:#1a2e22;overflow:hidden;-webkit-font-smoothing:antialiased}
:root{
  --bg:#f0f4f1;--bg2:#e8ede9;--bg3:#dde6de;
  --g:#3a7d5c;--gl:#5aa87a;--gs:#dff0e8;
  --b:#2563eb;--bs:rgba(37,99,235,.09);
  --p:#7c3aed;--ps:rgba(124,58,237,.09);
  --o:#c4874a;--os:#fdf0e2;
  --r:#dc2626;--rs:rgba(220,38,38,.09);
  --ink:#1a2e22;--mu:#5a7a65;
  --bd:rgba(58,125,92,.18);--card:rgba(240,244,241,.97);
}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-thumb{background:rgba(58,125,92,.22);border-radius:99px}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
@keyframes msgIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
@keyframes lockIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
@keyframes overlayIn{from{opacity:0}to{opacity:1}}
.fu{animation:fadeUp .35s ease both}
.lock{position:fixed;inset:0;background:linear-gradient(160deg,#1a2e22,#0d1f14);display:flex;align-items:center;justify-content:center;z-index:9999;flex-direction:column;animation:lockIn .4s ease}
.topbar{display:flex;align-items:center;height:52px;padding:0 14px;background:var(--card);border-bottom:1px solid var(--bd);flex-shrink:0;gap:10px;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);position:sticky;top:0;z-index:50}
.bnav{height:58px;background:var(--card);border-top:1px solid var(--bd);display:flex;align-items:center;justify-content:space-around;flex-shrink:0;padding-bottom:env(safe-area-inset-bottom,0px);flex-shrink:0}
.bni{display:flex;flex-direction:column;align-items:center;gap:3px;cursor:pointer;padding:7px 14px;border-radius:12px;transition:all .15s;touch-action:manipulation;min-width:52px;user-select:none;-webkit-user-select:none}
.bni.on{background:var(--gs)}.bni span{font-size:10px;font-weight:500;color:var(--mu)}.bni.on span{color:var(--g);font-weight:700}
.panel{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;min-height:0}
.back{display:inline-flex;align-items:center;gap:5px;padding:7px 14px 7px 9px;background:var(--gs);border:1px solid rgba(58,125,92,.25);border-radius:99px;color:var(--g);font-size:13px;font-weight:600;cursor:pointer;transition:all .15s;touch-action:manipulation;font-family:'Outfit',sans-serif;flex-shrink:0;user-select:none}
.back:active{transform:scale(.94)}
.ov{position:fixed;inset:0;background:rgba(26,46,34,.5);z-index:199;animation:overlayIn .2s ease;backdrop-filter:blur(3px)}
.sb{position:fixed;left:0;top:0;bottom:0;width:260px;background:var(--card);border-right:1px solid var(--bd);display:flex;flex-direction:column;z-index:200;transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1)}
.sb.open{transform:translateX(0)}
.ni{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;cursor:pointer;font-size:13.5px;color:var(--mu);transition:all .15s;border:1px solid transparent;touch-action:manipulation}
.ni:active{background:var(--gs)}.ni.on{background:var(--gs);color:var(--g);font-weight:600;border-color:rgba(58,125,92,.2)}
.card{background:var(--card);border:1px solid var(--bd);border-radius:16px;box-shadow:0 2px 12px rgba(58,125,92,.06)}
.hc{transition:transform .15s;cursor:pointer;touch-action:manipulation}.hc:active{transform:scale(.97)}
.inp{width:100%;background:rgba(240,244,241,.9);border:1px solid var(--bd);border-radius:10px;padding:10px 13px;font-family:'Outfit',sans-serif;font-size:14px;color:var(--ink);outline:none;transition:border-color .2s,box-shadow .2s;-webkit-appearance:none;appearance:none}
.inp:focus{border-color:var(--g);box-shadow:0 0 0 3px rgba(58,125,92,.1)}.inp::placeholder{color:var(--mu)}
.btn-g{background:var(--g);color:#fff;border:none;border-radius:10px;padding:10px 18px;font-family:'Outfit',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:7px;touch-action:manipulation}
.btn-g:active{transform:scale(.96)}.btn-g:disabled{opacity:.4;cursor:not-allowed;transform:none}
.btn-b{background:var(--bs);color:var(--b);border:1px solid rgba(37,99,235,.25);border-radius:10px;padding:10px 18px;font-family:'Outfit',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:7px;touch-action:manipulation}
.btn-b:active{transform:scale(.96)}.btn-b:disabled{opacity:.4;cursor:not-allowed}
.btn-o{background:transparent;color:var(--mu);border:1px solid var(--bd);border-radius:10px;padding:10px 18px;font-family:'Outfit',sans-serif;font-size:14px;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:7px;touch-action:manipulation}
.btn-o:active{background:var(--gs);color:var(--ink)}
.msg-u{background:var(--g);color:#fff;border-radius:16px 4px 16px 16px;padding:10px 14px;font-size:14px;line-height:1.6;max-width:82%;animation:msgIn .22s ease both;align-self:flex-end;word-break:break-word}
.msg-a{background:var(--card);border:1px solid var(--bd);border-radius:4px 16px 16px 16px;padding:10px 14px;font-size:14px;line-height:1.65;max-width:88%;animation:msgIn .22s ease both;align-self:flex-start;word-break:break-word;box-shadow:0 2px 8px rgba(58,125,92,.05)}
.dot-t{width:6px;height:6px;border-radius:99px;background:var(--g);display:inline-block;animation:pulse 1.2s ease infinite}
.cb{background:var(--bg3);border:1px solid var(--bd);border-radius:10px;padding:12px 14px;font-family:'JetBrains Mono',monospace;font-size:12px;overflow-x:auto;line-height:1.65;white-space:pre-wrap;word-break:break-all;color:var(--ink)}
.pill{display:inline-flex;align-items:center;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:600;gap:3px}
.pill-g{background:var(--gs);color:var(--g);border:1px solid rgba(58,125,92,.2)}
.pill-b{background:var(--bs);color:var(--b);border:1px solid rgba(37,99,235,.2)}
.pill-p{background:var(--ps);color:var(--p);border:1px solid rgba(124,58,237,.2)}
.pill-o{background:var(--os);color:var(--o);border:1px solid rgba(196,135,74,.2)}
.pill-r{background:var(--rs);color:var(--r);border:1px solid rgba(220,38,38,.2)}
.src{background:var(--bg2);border:1px solid var(--bd);border-radius:10px;padding:14px;margin-bottom:10px}
.chat-wrap{display:flex;flex-direction:column;height:100%;overflow:hidden}
.chat-msgs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:12px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
.chat-input{flex-shrink:0;padding:10px 14px;border-top:1px solid var(--bd);background:var(--card);backdrop-filter:blur(12px)}
`;

/* ── ICONS ── */
const I = ({ n, s = 16, c = "currentColor", st = {} }: any) => {
  const P: Record<string, string> = {
    home: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 22V12h6v10",
    search: "M11 17A6 6 0 1011 5a6 6 0 000 12z M21 21l-4.35-4.35",
    chat: "M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z",
    bot: "M12 2a2 2 0 012 2c0 .74-.4 1.38-1 1.73V7h3a3 3 0 013 3v8a3 3 0 01-3 3H8a3 3 0 01-3-3v-8a3 3 0 013-3h3V5.73A2 2 0 0110 4a2 2 0 012-2zM9 12a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm6 0a1.5 1.5 0 100 3 1.5 1.5 0 000-3z",
    set: "M12 15a3 3 0 100-6 3 3 0 000 6z M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z",
    send: "M22 2L11 13 M22 2l-7 20-4-9-9-4 20-7z",
    x: "M18 6L6 18M6 6l12 12", menu: "M3 12h18M3 6h18M3 18h18",
    arrl: "M19 12H5M12 5l-7 7 7 7",
    lock: "M19 11H5a2 2 0 00-2 2v7a2 2 0 002 2h14a2 2 0 002-2v-7a2 2 0 00-2-2z M7 11V7a5 5 0 0110 0v4",
    eye: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 12a3 3 0 100-6 3 3 0 000 6z",
    eyeoff: "M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94 M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19 M1 1l22 22",
    img: "M21 19V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2z M8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3z M21 15l-5-5L5 21",
    copy: "M20 9h-9a2 2 0 00-2 2v9a2 2 0 002 2h9a2 2 0 002-2v-9a2 2 0 00-2-2z M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1",
    check: "M20 6L9 17l-5-5", plus: "M12 5v14M5 12h14",
    trash: "M3 6h18 M19 6l-1 14H8L7 6 M10 11v6 M14 11v6 M9 6V4h6v2",
    globe: "M12 2a10 10 0 100 20A10 10 0 0012 2z M2 12h20 M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z",
    zap: "M13 2L3 14h9l-1 8 10-12h-9l1-8z",
    leaf: "M12 2a9 9 0 019 9c0 5.25-4 9.75-9 11-5-1.25-9-5.75-9-11a9 9 0 019-9z M12 2v20",
    brain: "M9.5 2A2.5 2.5 0 017 4.5v0A2.5 2.5 0 014.5 7H4a2 2 0 00-2 2v2a2 2 0 002 2h.5A2.5 2.5 0 017 15.5v0A2.5 2.5 0 019.5 18H11v2a2 2 0 004 0v-2h1.5A2.5 2.5 0 0119 15.5v0A2.5 2.5 0 0121.5 13H22a2 2 0 000-4h-.5A2.5 2.5 0 0119 6.5v0A2.5 2.5 0 0116.5 4H15V2a2 2 0 00-4 0v2H9.5z",
    paperclip: "M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48",
    file: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z M14 2v6h6",
    dl: "M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4 M7 10l5 5 5-5 M12 15V3",
    n8n: "M8 6l4-4 4 4 M12 2v10 M8 18l4 4 4-4 M12 22V12",
    key: "M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3",
    train: "M12 2a10 10 0 100 20A10 10 0 0012 2z M12 6v6l4 2",
  };
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={st}>
      {(P[n] || "").split(" M").map((d: string, i: number) => <path key={i} d={i === 0 ? d : "M" + d} />)}
    </svg>
  );
};

const Spin = ({ s = 15, c = "var(--g)" }: any) => (
  <div style={{ width: s, height: s, border: `2px solid rgba(58,125,92,.18)`, borderTop: `2px solid ${c}`, borderRadius: "50%", animation: "spin .7s linear infinite", flexShrink: 0 }} />
);

/* ── MARKDOWN RENDERER ── */
window.__dl = (name: string, enc: string) => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([decodeURIComponent(enc)], { type: "text/plain" }));
  a.download = name; a.click();
};

function md(t: string): string {
  if (!t) return "";
  return t
    .replace(/```email_action\n?([\s\S]*?)```/g, (_, c) => {
      try {
        const d = JSON.parse(c.trim());
        return `<div style="background:rgba(37,99,235,.07);border:1px solid rgba(37,99,235,.2);border-radius:10px;padding:12px;margin:8px 0"><div style="font-size:10px;font-weight:700;color:var(--b);letter-spacing:1px;margin-bottom:5px">📧 EMAIL SENT</div><div style="font-size:12.5px;color:var(--ink);line-height:1.6"><b>To:</b> ${d.to}<br/><b>Subject:</b> ${d.subject}</div></div>`;
      } catch { return ""; }
    })
    .replace(/```tg_action\n?([\s\S]*?)```/g, (_, c) => {
      try {
        const d = JSON.parse(c.trim());
        return `<div style="background:rgba(0,136,204,.07);border:1px solid rgba(0,136,204,.2);border-radius:10px;padding:12px;margin:8px 0"><div style="font-size:10px;font-weight:700;color:#0088cc;letter-spacing:1px;margin-bottom:5px">📱 SENT TO TELEGRAM</div><div style="font-size:12.5px;color:var(--ink)">${d.msg?.slice(0, 100)}</div></div>`;
      } catch { return ""; }
    })
    .replace(/```file_action:([^\n]+)\n([\s\S]*?)```/g, (_, fname, content) => {
      const enc = encodeURIComponent(content);
      return `<div style="background:rgba(58,125,92,.06);border:1px solid rgba(58,125,92,.2);border-radius:10px;padding:12px;margin:8px 0"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px"><span style="font-size:10px;font-weight:700;color:var(--g)">📄 ${fname}</span><button onclick="window.__dl('${fname}','${enc}')" style="background:var(--g);color:#fff;border:none;border-radius:7px;padding:5px 12px;font-size:12px;font-weight:600;cursor:pointer">⬇ Download</button></div><pre style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--ink);white-space:pre-wrap;max-height:80px;overflow:hidden">${content.replace(/</g, "&lt;").slice(0, 150)}...</pre></div>`;
    })
    .replace(/```mem_action\n?([\s\S]*?)```/g, (_, c) => {
      try {
        const d = JSON.parse(c.trim());
        addLocalMem(d.text, d.type);
        return `<div style="background:rgba(124,58,237,.07);border:1px solid rgba(124,58,237,.2);border-radius:10px;padding:10px 14px;margin:8px 0;font-size:13px;color:var(--p)">🧠 <b>Remembered:</b> ${d.text}</div>`;
      } catch { return ""; }
    })
    .replace(/```(\w*)\n?([\s\S]*?)```/g, (_, l, c) => `<pre class="cb" style="margin:8px 0">${c.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</pre>`)
    .replace(/`([^`]+)`/g, `<code style="background:var(--bg3);border-radius:4px;padding:1px 5px;font-family:'JetBrains Mono',monospace;font-size:.85em">$1</code>`)
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    .replace(/^### (.+)$/gm, `<h3 style="font-size:15px;font-weight:600;color:var(--ink);margin:10px 0 4px">$1</h3>`)
    .replace(/^## (.+)$/gm, `<h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:12px 0 5px">$1</h2>`)
    .replace(/^- (.+)$/gm, `<div style="display:flex;gap:7px;margin:3px 0"><span style="color:var(--g);font-weight:700;flex-shrink:0">•</span><span>$1</span></div>`)
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" target="_blank" style="color:var(--b);text-decoration:none;border-bottom:1px solid rgba(37,99,235,.3)">$1</a>`)
    .replace(/\n\n/g, "<br/><br/>").replace(/\n/g, "<br/>");
}

/* ── WEB RESEARCH (frontend — free, no API) ── */
async function doResearch(query: string) {
  const results: any[] = [];
  let answer = "", abstract = "";
  try {
    const r = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, { headers: { "User-Agent": "Lumis/2.0" } });
    const d = await r.json();
    answer = d.Answer || ""; abstract = d.Abstract || "";
    (d.RelatedTopics || []).slice(0, 5).forEach((t: any) => { if (t.Text && t.FirstURL) results.push({ title: t.Text.slice(0, 80), url: t.FirstURL, snippet: t.Text, src: "DuckDuckGo" }); });
    (d.Results || []).slice(0, 3).forEach((r: any) => { if (r.Text && r.FirstURL) results.push({ title: r.Text.slice(0, 80), url: r.FirstURL, snippet: r.Text, src: "DuckDuckGo" }); });
  } catch {}
  try {
    const w = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query.split(" ").slice(0, 3).join("_"))}`, { headers: { "User-Agent": "Lumis/2.0" } });
    if (w.ok) { const d = await w.json(); if (d.extract?.length > 50) results.unshift({ title: d.title, url: d.content_urls?.desktop?.page || "#", snippet: d.extract.slice(0, 300), src: "Wikipedia", thumb: d.thumbnail?.source }); }
  } catch {}
  return { query, answer, abstract, results };
}

/* ══════════════════════════════════════
   LOCK SCREEN
══════════════════════════════════════ */
function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);

  function tryUnlock() {
    if (pw === getPw()) { onUnlock(); }
    else { setErr("Wrong password"); setPw(""); setTimeout(() => setErr(""), 2000); }
  }

  return (
    <div className="lock">
      <div style={{ textAlign: "center", marginBottom: 36, animation: "fadeUp .5s ease" }}>
        <div style={{ width: 78, height: 78, borderRadius: 22, background: "linear-gradient(135deg,rgba(58,125,92,.25),rgba(90,168,122,.15))", border: "1px solid rgba(58,125,92,.3)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px" }}>
          <I n="leaf" s={34} c="#5aa87a" />
        </div>
        <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 46, fontWeight: 300, color: "#e8f0ea", letterSpacing: "4px" }}>Lumis</div>
        <div style={{ fontSize: 11, color: "rgba(200,230,212,.35)", letterSpacing: "4px", marginTop: 6 }}>PERSONAL AI</div>
      </div>
      <div style={{ width: "100%", maxWidth: 290, padding: "0 24px", animation: "fadeUp .5s ease .1s both" }}>
        <div style={{ position: "relative", marginBottom: 12 }}>
          <input className="inp" type={show ? "text" : "password"} value={pw} onChange={e => { setPw(e.target.value); setErr(""); }} onKeyDown={e => e.key === "Enter" && tryUnlock()} placeholder="Password" autoFocus
            style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(58,125,92,.22)", color: "#e8f0ea", borderRadius: 12, padding: "14px 46px 14px 16px", fontSize: 15, textAlign: "center", letterSpacing: "3px" }} />
          <button onClick={() => setShow(!show)} style={{ position: "absolute", right: 13, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", padding: 4 }}>
            <I n={show ? "eyeoff" : "eye"} s={16} c="rgba(200,230,212,.5)" />
          </button>
        </div>
        {err && <div style={{ color: "#f87171", fontSize: 13, textAlign: "center", marginBottom: 10 }}>{err}</div>}
        <button onClick={tryUnlock} className="btn-g" style={{ width: "100%", justifyContent: "center", fontSize: 15, padding: "14px", borderRadius: 12 }}>
          <I n="zap" s={15} c="#fff" /> Enter Lumis
        </button>
        <div style={{ textAlign: "center", marginTop: 14, fontSize: 11, color: "rgba(200,230,212,.25)" }}>Default: lumis2024</div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   LUMIS CHAT
══════════════════════════════════════ */
function LumisChat({ onBack }: any) {
  const [msgs, setMsgs] = useState<any[]>([]);
  const [inp, setInp] = useState("");
  const [loading, setLoading] = useState(false);
  const [attached, setAttached] = useState<any>(null);
  const [status, setStatus] = useState("");
  const [copied, setCopied] = useState<any>(null);
  const [drag, setDrag] = useState(false);
  const botRef = useRef<any>(null);
  const inpRef = useRef<any>(null);
  const fileRef = useRef<any>(null);
  const sessionId = useRef(getSession());

  useEffect(() => { botRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, loading]);

  function handleFile(f: File) {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = ev => setAttached({ base64: (ev.target!.result as string).split(",")[1], mime: f.type || "image/jpeg", preview: ev.target!.result as string, name: f.name, isImage: f.type.startsWith("image/") });
    reader.readAsDataURL(f);
  }

  async function send() {
    if ((!inp.trim() && !attached) || loading) return;
    const txt = inp.trim() || (attached?.isImage ? "Analyze this image." : `File: ${attached?.name}`);
    setInp(""); const att = attached; setAttached(null);
    const userMsg = { role: "user", content: txt, att };
    const newMsgs = [...msgs, userMsg];
    setMsgs(newMsgs);
    setLoading(true);

    try {
      const apiMsgs = newMsgs.map((m: any) => ({ role: m.role, content: m.content }));
      const body: any = { messages: apiMsgs, sessionId: sessionId.current };
      if (att?.isImage) { body.imageBase64 = att.base64; body.imageMime = att.mime; }

      const res = await fetch("/api/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const d = await res.json();

      if (!res.ok) throw new Error(d.error || "API error");

      const reply = d.reply || "No response.";
      setMsgs([...newMsgs, { role: "assistant", content: reply }]);

      // Show action results
      if (d.actions?.email) setStatus(`✅ Email sent to ${d.actions.email.to}`);
      else if (d.actions?.telegram) setStatus(`✅ Sent to Telegram`);
      if (d.actions?.email || d.actions?.telegram) setTimeout(() => setStatus(""), 4000);
    } catch (e: any) {
      setMsgs([...newMsgs, { role: "assistant", content: `⚠️ **Error:** ${e.message}\n\nCheck that the app is deployed correctly and OPENCLAUDE_API_KEY is set in Vercel env vars.` }]);
    }

    setLoading(false);
    setTimeout(() => inpRef.current?.focus(), 80);
  }

  function cp(t: string, i: number) { navigator.clipboard?.writeText(t); setCopied(i); setTimeout(() => setCopied(null), 1500); }
  const localMem = getLocalMem();

  return (
    <div className="chat-wrap" onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setDrag(false); }} onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}>
      {/* Topbar */}
      <div className="topbar">
        <button className="back" onClick={onBack}><I n="arrl" s={14} c="var(--g)" /> Home</button>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 17, color: "var(--ink)" }}>Lumis Chat</span>
          {localMem.length > 0 && <span className="pill pill-p" style={{ fontSize: 9 }}><I n="brain" s={9} c="var(--p)" />{localMem.length}</span>}
        </div>
        <label htmlFor="lumis-file" style={{ background: "var(--gs)", border: "1px solid rgba(58,125,92,.25)", borderRadius: 9, padding: "7px 11px", cursor: "pointer", color: "var(--g)", display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 600 }}>
          <I n="paperclip" s={14} c="var(--g)" />
          <input id="lumis-file" ref={fileRef} type="file" accept="image/*,.pdf,.txt,.md,.csv,.js,.py,.ts,.json,.docx,.xlsx,.zip" style={{ display: "none" }} onChange={e => handleFile(e.target.files![0])} />
        </label>
        <button onClick={() => setMsgs([])} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--mu)", padding: 6, borderRadius: 7 }}><I n="trash" s={15} /></button>
      </div>

      {status && <div style={{ background: "rgba(58,125,92,.08)", borderBottom: "1px solid rgba(58,125,92,.15)", padding: "8px 16px", fontSize: 13, color: "var(--g)", flexShrink: 0 }}>{status}</div>}

      {drag && <div style={{ position: "absolute", inset: 0, background: "rgba(58,125,92,.1)", border: "2px dashed var(--g)", zIndex: 20, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 10, pointerEvents: "none" }}><I n="upload" s={36} c="var(--g)" /><div style={{ fontSize: 16, fontWeight: 600, color: "var(--g)" }}>Drop file here</div></div>}

      {/* Messages */}
      <div className="chat-msgs">
        {msgs.length === 0 && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 320, gap: 12, opacity: .55, padding: "0 20px" }}>
            <div style={{ background: "var(--bg3)", border: "1px solid var(--bd)", borderRadius: 12, padding: 18, width: "100%", maxWidth: 300, fontFamily: "'JetBrains Mono',monospace", fontSize: 12.5, color: "var(--g)", lineHeight: 1.8 }}>
              <div style={{ display: "flex", gap: 7, marginBottom: 12, alignItems: "center" }}>
                <div style={{ width: 11, height: 11, borderRadius: 99, background: "#f87171" }} />
                <div style={{ width: 11, height: 11, borderRadius: 99, background: "#fbbf24" }} />
                <div style={{ width: 11, height: 11, borderRadius: 99, background: "var(--g)" }} />
                <span style={{ color: "var(--mu)", marginLeft: 8, fontSize: 11 }}>lumis — ai</span>
              </div>
              {">"} Hi Pratik! Ready<br />
              <span style={{ color: "var(--mu)" }}>{">"} {localMem.length} memories loaded</span><br />
              {">"} Ask anything<span style={{ display: "inline-block", width: 7, height: 13, background: "var(--g)", animation: "blink 1s step-end infinite", verticalAlign: "text-bottom", marginLeft: 2 }} />
            </div>
            <div style={{ fontSize: 13, color: "var(--mu)", textAlign: "center", lineHeight: 1.7 }}>
              <em>"10 names email karo"</em><br /><em>"Bot pe bhej do"</em><br /><em>"Yaad rakh..."</em> · Upload images
            </div>
          </div>
        )}
        {msgs.map((m: any, i: number) => (
          <div key={i} style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: m.role === "user" ? "flex-end" : "flex-start" }}>
            {m.att && (
              m.att.isImage
                ? <img src={m.att.preview} alt={m.att.name} style={{ maxWidth: 200, maxHeight: 160, borderRadius: 10, border: "1px solid var(--bd)", objectFit: "contain", alignSelf: "flex-end" }} />
                : <div style={{ background: "var(--gs)", border: "1px solid rgba(58,125,92,.2)", borderRadius: 8, padding: "6px 11px", fontSize: 12, color: "var(--g)", display: "flex", alignItems: "center", gap: 5, alignSelf: "flex-end" }}><I n="file" s={13} c="var(--g)" />{m.att.name}</div>
            )}
            <div className={m.role === "user" ? "msg-u" : "msg-a"} dangerouslySetInnerHTML={m.role === "assistant" ? { __html: md(m.content) } : undefined}>
              {m.role === "user" ? m.content : undefined}
            </div>
            {m.role === "assistant" && (
              <button onClick={() => cp(m.content, i)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--mu)", display: "flex", alignItems: "center", gap: 4, fontSize: 11, padding: "2px 4px" }}>
                <I n={copied === i ? "check" : "copy"} s={11} c={copied === i ? "var(--g)" : "var(--mu)"} />{copied === i ? "Copied" : "Copy"}
              </button>
            )}
          </div>
        ))}
        {loading && <div className="msg-a" style={{ display: "flex", alignItems: "center", gap: 5, padding: "12px 14px", alignSelf: "flex-start" }}><span className="dot-t" style={{ animationDelay: "0s" }} /><span className="dot-t" style={{ animationDelay: ".2s" }} /><span className="dot-t" style={{ animationDelay: ".4s" }} /></div>}
        <div ref={botRef} style={{ height: 1, flexShrink: 0 }} />
      </div>

      {/* Attachment preview */}
      {attached && (
        <div style={{ padding: "8px 14px", borderTop: "1px solid var(--bd)", background: "var(--card)", display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
          {attached.isImage ? <img src={attached.preview} style={{ width: 36, height: 36, borderRadius: 7, objectFit: "cover", border: "1px solid var(--bd)" }} /> : <div style={{ width: 36, height: 36, borderRadius: 7, background: "var(--gs)", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="file" s={16} c="var(--g)" /></div>}
          <div style={{ flex: 1, fontSize: 12.5, color: "var(--mu)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{attached.name}</div>
          <button onClick={() => setAttached(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--mu)", padding: 4 }}><I n="x" s={16} /></button>
        </div>
      )}

      {/* Input */}
      <div className="chat-input">
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <textarea ref={inpRef} className="inp" value={inp} onChange={e => setInp(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder="Ask Lumis anything…" rows={1}
            style={{ resize: "none", flex: 1, minHeight: 44, maxHeight: 110, overflowY: "auto", borderRadius: 12, lineHeight: 1.5, fontSize: 14 }}
            onInput={(e: any) => { e.target.style.height = "auto"; e.target.style.height = Math.min(e.target.scrollHeight, 110) + "px"; }} />
          <button className="btn-g" onClick={send} disabled={loading || (!inp.trim() && !attached)} style={{ padding: "11px 13px", borderRadius: 12, flexShrink: 0, justifyContent: "center", height: 44 }}>
            {loading ? <Spin s={14} c="#fff" /> : <I n="send" s={15} c="#fff" />}
          </button>
        </div>
        <div style={{ fontSize: 10.5, color: "var(--mu)", marginTop: 4, textAlign: "center" }}>Shift+Enter = new line · 📎 to attach</div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   RESEARCH
══════════════════════════════════════ */
function Research({ onBack }: any) {
  const [q, setQ] = useState(""); const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null); const [aiSum, setAiSum] = useState(""); const [aiLoad, setAiLoad] = useState(false);
  async function search() {
    if (!q.trim()) return; setLoading(true); setResult(null); setAiSum("");
    const r = await doResearch(q); setResult(r); setLoading(false);
    if (r.results.length > 0) {
      setAiLoad(true);
      const ctx = r.results.map((x: any) => x.snippet).join("\n\n");
      try {
        const res = await fetch("/api/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: [{ role: "user", content: `Research: "${q}"\n\nSources:\n${ctx}\n\nGive comprehensive summary with key points.` }], sessionId: "research" }) });
        const d = await res.json(); setAiSum(d.reply || "");
      } catch {}
      setAiLoad(false);
    }
  }
  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div className="topbar"><button className="back" onClick={onBack}><I n="arrl" s={14} c="var(--g)" /> Home</button><span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 17, color: "var(--ink)", flex: 1 }}>Open Research</span><span className="pill pill-g" style={{ fontSize: 10 }}>Free</span></div>
      <div className="panel" style={{ padding: 14 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <div style={{ position: "relative", flex: 1 }}>
            <I n="search" s={14} c="var(--mu)" st={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)" }} />
            <input className="inp" style={{ paddingLeft: 34 }} value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === "Enter" && search()} placeholder="Search Wikipedia, DuckDuckGo, AI…" />
          </div>
          <button className="btn-g" onClick={search} disabled={loading || !q.trim()} style={{ padding: "9px 15px", flexShrink: 0 }}>
            {loading ? <Spin s={14} c="#fff" /> : <I n="search" s={14} c="#fff" />}
          </button>
        </div>
        {!result && !loading && <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginBottom: 12 }}>{["Wikipedia", "DuckDuckGo", "AI Synthesis"].map(x => <span key={x} className="pill pill-g" style={{ fontSize: 10 }}>{x}</span>)}</div>}
        {loading && [1, 2, 3].map(i => <div key={i} style={{ background: "var(--bg2)", border: "1px solid var(--bd)", borderRadius: 10, padding: 14, marginBottom: 10, animation: "pulse 1.5s ease infinite", animationDelay: `${i * .12}s` }}><div style={{ height: 12, background: "var(--bg3)", borderRadius: 4, width: "55%", marginBottom: 7 }} /><div style={{ height: 10, background: "var(--bg3)", borderRadius: 4, width: "88%", marginBottom: 5 }} /><div style={{ height: 10, background: "var(--bg3)", borderRadius: 4, width: "70%" }} /></div>)}
        {result && (
          <div className="fu">
            {result.answer && <div style={{ background: "var(--gs)", border: "1px solid rgba(58,125,92,.2)", borderRadius: 12, padding: 14, marginBottom: 12 }}><div style={{ fontSize: 10, fontWeight: 700, color: "var(--g)", letterSpacing: "1px", marginBottom: 5 }}>DIRECT ANSWER</div><div style={{ fontSize: 15, color: "var(--ink)", lineHeight: 1.6 }}>{result.answer}</div></div>}
            {(aiSum || aiLoad) && <div style={{ background: "var(--card)", border: "1px solid rgba(124,58,237,.2)", borderRadius: 12, padding: 14, marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}><div style={{ fontSize: 10, fontWeight: 700, color: "var(--p)", letterSpacing: "1px" }}>AI SYNTHESIS</div>{aiLoad && <Spin s={13} c="var(--p)" />}</div>{aiSum ? <div style={{ fontSize: 13.5, color: "var(--ink)", lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: md(aiSum) }} /> : <div style={{ fontSize: 13, color: "var(--mu)", display: "flex", alignItems: "center", gap: 7 }}><Spin s={13} c="var(--p)" />Synthesizing…</div>}</div>}
            {result.abstract && <div style={{ background: "var(--bg2)", border: "1px solid var(--bd)", borderRadius: 12, padding: 14, marginBottom: 12, fontSize: 13.5, color: "var(--ink)", lineHeight: 1.7 }}><div style={{ fontSize: 10, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 7 }}>SUMMARY</div>{result.abstract}</div>}
            <div style={{ fontSize: 10, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 8 }}>SOURCES ({result.results.length})</div>
            {result.results.map((r: any, i: number) => (
              <div key={i} className="src">
                <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                  {r.thumb && <img src={r.thumb} style={{ width: 42, height: 42, borderRadius: 7, objectFit: "cover", flexShrink: 0, border: "1px solid var(--bd)" }} onError={(e: any) => e.target.style.display = "none"} />}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", gap: 7, alignItems: "center", marginBottom: 4 }}>
                      <a href={r.url} target="_blank" rel="noreferrer" style={{ fontSize: 13.5, fontWeight: 600, color: "var(--b)", textDecoration: "none", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>{r.title}</a>
                      <span className={`pill ${r.src === "Wikipedia" ? "pill-b" : "pill-o"}`} style={{ flexShrink: 0, fontSize: 9 }}>{r.src}</span>
                    </div>
                    <div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{r.snippet}</div>
                    <a href={r.url} target="_blank" rel="noreferrer" style={{ fontSize: 10.5, color: "rgba(37,99,235,.6)", textDecoration: "none", marginTop: 4, display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.url}</a>
                  </div>
                </div>
              </div>
            ))}
            {!result.results.length && !result.answer && <div style={{ textAlign: "center", color: "var(--mu)", padding: 32, fontSize: 14 }}>No results found.</div>}
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   BOT SETUP
══════════════════════════════════════ */
function BotSetup({ onBack }: any) {
  const [wRes, setWRes] = useState(""); const [loading, setLoading] = useState(false);

  async function registerWebhook() {
    setLoading(true);
    try {
      const res = await fetch(`/api/telegram/webhook?secret=${encodeURIComponent(getPw())}`);
      const d = await res.json();
      setWRes(d.telegram?.ok ? `✅ Webhook set!\n${d.webhook_url}` : `❌ ${d.telegram?.description || d.error}`);
    } catch (e: any) { setWRes("❌ " + e.message); }
    setLoading(false);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div className="topbar"><button className="back" onClick={onBack}><I n="arrl" s={14} c="var(--g)" /> Home</button><span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 17, color: "var(--ink)", flex: 1 }}>Telegram + n8n</span></div>
      <div className="panel" style={{ padding: 14 }}>

        <div className="card" style={{ padding: 16, marginBottom: 12, background: "linear-gradient(135deg,rgba(58,125,92,.04),rgba(37,99,235,.03))" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--g)", letterSpacing: "1px", marginBottom: 12 }}>ARCHITECTURE</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { icon: "🌐", t: "Website", d: "You chat → /api/ai (backend) → OpenClaude → reply" },
              { icon: "📱", t: "Telegram Bot", d: "You message bot → /api/telegram/webhook → same /api/ai → reply" },
              { icon: "🔗", t: "Cross-channel", d: "\"Bot pe bhej do\" → website calls /api/ai → Telegram API → your bot sends message" },
              { icon: "🧠", t: "Same Brain", d: "Both channels use identical AI backend with same memory & training" },
            ].map(({ icon, t, d }) => (
              <div key={t} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <span style={{ fontSize: 20, flexShrink: 0 }}>{icon}</span>
                <div><div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--ink)", marginBottom: 2 }}>{t}</div><div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.5 }}>{d}</div></div>
              </div>
            ))}
          </div>
        </div>

        <div className="card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 10 }}>VERCEL ENV VARS NEEDED</div>
          <div style={{ background: "var(--bg3)", borderRadius: 10, padding: 12, fontFamily: "'JetBrains Mono',monospace", fontSize: 11, lineHeight: 1.9, color: "var(--ink)" }}>
            OPENCLAUDE_API_KEY=fe_oa_...<br />
            OPENCLAUDE_BASE_URL=https://cc.freemodel.dev<br />
            OPENCLAUDE_MODEL=claude-sonnet-4-6<br />
            TELEGRAM_BOT_TOKEN=from_botfather<br />
            TELEGRAM_OWNER_ID=your_telegram_id<br />
            GMAIL_USER=lumis.chat@gmail.com<br />
            GMAIL_APP_PASSWORD=xxxx_xxxx<br />
            OWNER_NAME=Pratik Pandey<br />
            OWNER_EMAIL=pratikpandey318@gmail.com<br />
            MONGODB_URI=mongodb+srv://...<br />
            APP_PASSWORD=lumis2024<br />
            NEXT_PUBLIC_APP_URL=https://yourapp.vercel.app
          </div>
          <div style={{ fontSize: 12, color: "var(--mu)", marginTop: 8 }}>Add at: <strong>Vercel → Project → Settings → Environment Variables</strong></div>
        </div>

        <div className="card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 10 }}>SETUP STEPS</div>
          {[
            { n: "1", t: "BotFather", d: "@BotFather → /newbot → copy token → add to Vercel TELEGRAM_BOT_TOKEN" },
            { n: "2", t: "Your Telegram ID", d: "Message @userinfobot → copy ID → add to TELEGRAM_OWNER_ID" },
            { n: "3", t: "Deploy", d: "Push to GitHub → Vercel auto-deploys with all env vars" },
            { n: "4", t: "Register Webhook", d: "Click button below — connects bot to your backend automatically" },
            { n: "5", t: "Test", d: "Send /start to your bot → it should reply using Lumis AI!" },
          ].map(s => (
            <div key={s.n} style={{ display: "flex", gap: 12, marginBottom: 10 }}>
              <div style={{ width: 24, height: 24, borderRadius: 99, background: "var(--gs)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "var(--g)", flexShrink: 0 }}>{s.n}</div>
              <div><div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--ink)", marginBottom: 1 }}>{s.t}</div><div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.5 }}>{s.d}</div></div>
            </div>
          ))}
          <button onClick={registerWebhook} className="btn-g" disabled={loading} style={{ width: "100%", justifyContent: "center", marginTop: 4 }}>
            {loading ? <><Spin s={14} c="#fff" />Registering…</> : <><I n="bot" s={14} c="#fff" />Register Webhook</>}
          </button>
          {wRes && <div style={{ marginTop: 10, padding: "10px 14px", background: wRes.startsWith("✅") ? "var(--gs)" : "rgba(220,38,38,.07)", border: `1px solid ${wRes.startsWith("✅") ? "rgba(58,125,92,.2)" : "rgba(220,38,38,.2)"}`, borderRadius: 10, fontSize: 12.5, color: wRes.startsWith("✅") ? "var(--g)" : "var(--r)", whiteSpace: "pre-wrap" }}>{wRes}</div>}
        </div>

        <div className="card" style={{ padding: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 10 }}>N8N (OPTIONAL — for advanced workflows)</div>
          <div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.7, marginBottom: 10 }}>
            n8n can be used for complex automations beyond simple bot replies — scheduling, multi-step workflows, integrations. For basic Telegram AI chat, <strong>the built-in webhook above is enough</strong> (no n8n needed).
          </div>
          <div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.7 }}>
            If you want n8n: <a href="https://app.n8n.cloud" target="_blank" style={{ color: "var(--b)" }}>n8n.cloud</a> (free tier) → Create workflow → Telegram Trigger → HTTP Request to <code style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, background: "var(--bg3)", padding: "1px 5px", borderRadius: 4 }}>/api/ai</code> → Telegram reply
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   MEMORY PANEL
══════════════════════════════════════ */
function MemoryView({ onBack }: any) {
  const [mems, setMems] = useState<any[]>([]);
  const [addTxt, setAddTxt] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try backend first, fallback to local
    fetch("/api/memory").then(r => r.json()).then(d => {
      if (d.mems?.length) setMems(d.mems);
      else setMems(getLocalMem());
    }).catch(() => setMems(getLocalMem())).finally(() => setLoading(false));
  }, []);

  async function add() {
    if (!addTxt.trim()) return;
    addLocalMem(addTxt.trim(), "manual");
    try { await fetch("/api/memory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: addTxt.trim(), type: "manual", importance: 5 }) }); } catch {}
    setMems(getLocalMem()); setAddTxt("");
  }

  async function del(id: string) {
    const m = getLocalMem().filter((x: any) => x.id !== id);
    try { localStorage.setItem("lumis_mem", JSON.stringify(m)); } catch {}
    try { await fetch("/api/memory", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) }); } catch {}
    setMems(m);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div className="topbar"><button className="back" onClick={onBack}><I n="arrl" s={14} c="var(--g)" /> Home</button><span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 17, color: "var(--ink)", flex: 1 }}>Memory</span><span className="pill pill-p"><I n="brain" s={10} c="var(--p)" />{mems.length}</span></div>
      <div className="panel" style={{ padding: 14 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <input className="inp" value={addTxt} onChange={e => setAddTxt(e.target.value)} onKeyDown={e => e.key === "Enter" && add()} placeholder="Add something to remember…" style={{ flex: 1 }} />
          <button className="btn-g" onClick={add} style={{ padding: "9px 13px" }}><I n="plus" s={14} c="#fff" /></button>
        </div>
        {loading && <div style={{ textAlign: "center", padding: 30 }}><Spin /></div>}
        {!loading && mems.length === 0 && <div style={{ textAlign: "center", color: "var(--mu)", padding: 40, fontSize: 13 }}>No memories yet.<br />Say <em>"yaad rakh..."</em> in chat!</div>}
        {[...mems].reverse().map((m: any) => (
          <div key={m.id || m._id} className="card" style={{ padding: "12px 14px", marginBottom: 9, display: "flex", alignItems: "flex-start", gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 9.5, color: "var(--p)", fontWeight: 700, letterSpacing: ".8px", marginBottom: 3 }}>{(m.type || "fact").toUpperCase()}</div>
              <div style={{ fontSize: 13.5, color: "var(--ink)", lineHeight: 1.5 }}>{m.text}</div>
              {m.ts && <div style={{ fontSize: 10.5, color: "var(--mu)", marginTop: 4 }}>{new Date(m.ts).toLocaleDateString()}</div>}
            </div>
            <button onClick={() => del(m.id || m._id)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--mu)", padding: 4, flexShrink: 0 }}><I n="trash" s={14} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   SETTINGS — only password change here
   All other secrets are in Vercel env vars
══════════════════════════════════════ */
function Settings({ onBack, onLock }: any) {
  const [newPw, setNewPw] = useState(""); const [cPw, setCPw] = useState(""); const [msg, setMsg] = useState("");
  const [trainRes, setTrainRes] = useState(""); const [training, setTraining] = useState(false);

  function changePw() {
    if (newPw.length < 4) { setMsg("Min 4 characters"); return; }
    if (newPw !== cPw) { setMsg("Don't match"); return; }
    setPw(newPw); setMsg("✓ Password changed!"); setNewPw(""); setCPw("");
    setTimeout(() => setMsg(""), 2500);
  }

  async function runTrain() {
    setTraining(true);
    try {
      const res = await fetch(`/api/train`, { headers: { authorization: `Bearer ${getPw()}` } });
      const d = await res.json();
      setTrainRes(d.ok ? `✅ Trained on: ${d.topic}\nItems added: ${d.added}` : `❌ ${d.error}`);
    } catch (e: any) { setTrainRes("❌ " + e.message); }
    setTraining(false);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div className="topbar"><button className="back" onClick={onBack}><I n="arrl" s={14} c="var(--g)" /> Home</button><span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 17, color: "var(--ink)", flex: 1 }}>Settings</span><button onClick={onLock} className="btn-o" style={{ fontSize: 12, padding: "7px 11px" }}><I n="lock" s={13} />Lock</button></div>
      <div className="panel" style={{ padding: 14 }}>

        <div className="card" style={{ padding: 16, marginBottom: 12, background: "rgba(37,99,235,.04)", borderColor: "rgba(37,99,235,.15)" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--b)", letterSpacing: "1px", marginBottom: 10 }}>ℹ️ SECURITY MODEL</div>
          <div style={{ fontSize: 13, color: "var(--ink)", lineHeight: 1.8 }}>
            All secrets (API key, Gmail, Telegram token) are stored in <strong>Vercel Environment Variables</strong> — never in browser, never in code.<br /><br />
            <strong>Add/change secrets at:</strong><br />
            Vercel → Project → Settings → Environment Variables
          </div>
        </div>

        <div className="card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--p)", letterSpacing: "1px", marginBottom: 12 }}>🔒 LOCK SCREEN PASSWORD</div>
          <div style={{ marginBottom: 8 }}><input className="inp" type="password" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="New password (min 4 chars)" /></div>
          <div style={{ marginBottom: 12 }}><input className="inp" type="password" value={cPw} onChange={e => setCPw(e.target.value)} placeholder="Confirm" onKeyDown={e => e.key === "Enter" && changePw()} /></div>
          {msg && <div style={{ fontSize: 12.5, color: msg.startsWith("✓") ? "var(--g)" : "var(--r)", marginBottom: 8 }}>{msg}</div>}
          <button onClick={changePw} className="btn-b" style={{ fontSize: 13, padding: "8px 14px" }}><I n="lock" s={13} />Change Password</button>
        </div>

        <div className="card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--g)", letterSpacing: "1px", marginBottom: 10 }}>🧠 MANUAL TRAINING</div>
          <div style={{ fontSize: 12.5, color: "var(--mu)", lineHeight: 1.6, marginBottom: 12 }}>
            Lumis auto-trains every 6 hours via Vercel Cron. Click below to trigger manually.
          </div>
          <button onClick={runTrain} className="btn-g" disabled={training} style={{ width: "100%", justifyContent: "center" }}>
            {training ? <><Spin s={14} c="#fff" />Training…</> : <><I n="train" s={14} c="#fff" />Run Training Now</>}
          </button>
          {trainRes && <div style={{ marginTop: 10, padding: "10px 14px", background: trainRes.startsWith("✅") ? "var(--gs)" : "rgba(220,38,38,.07)", borderRadius: 10, fontSize: 12.5, color: trainRes.startsWith("✅") ? "var(--g)" : "var(--r)", whiteSpace: "pre-wrap" }}>{trainRes}</div>}
        </div>

        <div className="card" style={{ padding: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 10 }}>📋 REQUIRED ENV VARS</div>
          {[
            { k: "OPENCLAUDE_API_KEY", v: "fe_oa_...", req: true },
            { k: "OPENCLAUDE_BASE_URL", v: "https://cc.freemodel.dev", req: true },
            { k: "TELEGRAM_BOT_TOKEN", v: "from @BotFather", req: false },
            { k: "TELEGRAM_OWNER_ID", v: "from @userinfobot", req: false },
            { k: "GMAIL_USER", v: "lumis.chat@gmail.com", req: false },
            { k: "GMAIL_APP_PASSWORD", v: "xxxx xxxx xxxx", req: false },
            { k: "MONGODB_URI", v: "mongodb+srv://...", req: false },
            { k: "OWNER_NAME", v: "Pratik Pandey", req: true },
            { k: "OWNER_EMAIL", v: "pratikpandey318@gmail.com", req: true },
            { k: "APP_PASSWORD", v: "lumis2024", req: true },
            { k: "NEXT_PUBLIC_APP_URL", v: "https://yourapp.vercel.app", req: true },
            { k: "CRON_SECRET", v: "random string", req: false },
          ].map(({ k, v, req }) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid var(--bd)", alignItems: "center", gap: 8 }}>
              <div>
                <code style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "var(--ink)" }}>{k}</code>
                {req && <span style={{ fontSize: 10, color: "var(--r)", marginLeft: 5 }}>*required</span>}
                <div style={{ fontSize: 11, color: "var(--mu)" }}>{v}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   HOME
══════════════════════════════════════ */
function Home({ setView }: any) {
  const localMem = getLocalMem();
  const tiles = [
    { id: "research", i: "search", l: "Research", d: "Wikipedia + DuckDuckGo + AI", c: "var(--b)", bg: "var(--bs)", badge: "Free · No API" },
    { id: "chat", i: "chat", l: "Lumis Chat", d: "AI · images · email · Telegram · files", c: "var(--g)", bg: "var(--gs)", badge: "Full AI" },
    { id: "bot", i: "bot", l: "Telegram Bot", d: "Same AI, setup guide & webhook", c: "var(--o)", bg: "var(--os)", badge: "n8n optional" },
    { id: "memory", i: "brain", l: "Memory", d: `${localMem.length} items remembered`, c: "var(--p)", bg: "var(--ps)", badge: `${localMem.length} memories` },
  ];
  return (
    <div className="panel" style={{ padding: "18px 16px" }}>
      <div style={{ marginBottom: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <div style={{ width: 42, height: 42, borderRadius: 13, background: "var(--gs)", border: "1px solid rgba(58,125,92,.2)", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="leaf" s={21} c="var(--g)" /></div>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 30, fontWeight: 400, color: "var(--ink)", lineHeight: 1 }}>Lumis</div>
            <div style={{ fontSize: 11, color: "var(--mu)" }}>Personal AI · Backend Secured</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          <span className="pill pill-g"><span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--g)", display: "inline-block" }} />Backend Active</span>
          <span className="pill pill-b"><I n="globe" s={9} />Research Ready</span>
          <span className="pill pill-p"><I n="brain" s={9} c="var(--p)" />{localMem.length} Memories</span>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 11, marginBottom: 18 }}>
        {tiles.map((t, i) => (
          <div key={t.id} className="card hc fu" onClick={() => setView(t.id)} style={{ padding: 15, animationDelay: `${i * .06}s` }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: t.bg, border: `1px solid ${t.c}22`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}><I n={t.i} s={16} c={t.c} /></div>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--ink)", marginBottom: 4, lineHeight: 1.2 }}>{t.l}</div>
            <div style={{ fontSize: 11.5, color: "var(--mu)", lineHeight: 1.5, marginBottom: 7 }}>{t.d}</div>
            <span className={`pill ${t.id === "chat" ? "pill-g" : t.id === "bot" ? "pill-o" : t.id === "memory" ? "pill-p" : "pill-b"}`} style={{ fontSize: 9.5 }}>{t.badge}</span>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--mu)", letterSpacing: "1px", marginBottom: 10 }}>LUMIS UNDERSTANDS</div>
        {[
          { t: "Email", d: "\"10 names email karo\" → generates + sends automatically" },
          { t: "Telegram", d: "\"Bot pe bhej do\" → sends to your Telegram bot" },
          { t: "Files", d: "\"Text file mein de do\" → downloadable file" },
          { t: "Memory", d: "\"Yaad rakh main React use karta hoon\" → remembered" },
          { t: "Images", d: "Upload any photo → AI analyzes it" },
          { t: "Self-trains", d: "Every 6 hours Lumis studies and improves itself" },
        ].map(({ t, d }) => (
          <div key={t} style={{ display: "flex", gap: 10, marginBottom: 7 }}>
            <span className="pill pill-g" style={{ fontSize: 10, flexShrink: 0, alignSelf: "flex-start", marginTop: 1 }}>{t}</span>
            <span style={{ fontSize: 12, color: "var(--mu)", lineHeight: 1.4 }}>{d}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════
   ROOT APP
══════════════════════════════════════ */
export default function LumisApp() {
  const [locked, setLocked] = useState(true);
  const [view, setView] = useState("home");
  const [sbOpen, setSbOpen] = useState(false);

  useEffect(() => {
    if (!document.getElementById("lumis-css")) {
      const el = document.createElement("style");
      el.id = "lumis-css"; el.textContent = CSS;
      document.head.appendChild(el);
    }
  }, []);

  const nav = [
    { id: "home", i: "home", l: "Home" },
    { id: "research", i: "search", l: "Research" },
    { id: "chat", i: "chat", l: "Chat" },
    { id: "bot", i: "bot", l: "Bot" },
    { id: "settings", i: "set", l: "Settings" },
  ];

  function panel() {
    const ob = { onBack: () => setView("home") };
    switch (view) {
      case "home": return <Home setView={setView} />;
      case "research": return <Research {...ob} />;
      case "chat": return <LumisChat {...ob} />;
      case "bot": return <BotSetup {...ob} />;
      case "memory": return <MemoryView {...ob} />;
      case "settings": return <Settings {...ob} onLock={() => setLocked(true)} />;
      default: return <Home setView={setView} />;
    }
  }

  if (locked) return <LockScreen onUnlock={() => setLocked(false)} />;

  return (
    <div style={{ width: "100%", height: "100vh", display: "flex", flexDirection: "column", background: "var(--bg)", overflow: "hidden", fontFamily: "'Outfit',sans-serif", color: "var(--ink)" }}>
      {/* Blobs */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", width: 360, height: 360, borderRadius: "50%", background: "radial-gradient(circle,rgba(58,125,92,.16),transparent 70%)", top: -100, right: -60, filter: "blur(70px)", animation: "pulse 8s ease infinite" }} />
        <div style={{ position: "absolute", width: 280, height: 280, borderRadius: "50%", background: "radial-gradient(circle,rgba(37,99,235,.07),transparent 70%)", bottom: -80, left: -40, filter: "blur(70px)", animation: "pulse 10s ease infinite", animationDelay: "-4s" }} />
      </div>

      {sbOpen && <div className="ov" onClick={() => setSbOpen(false)} />}
      <aside className={`sb${sbOpen ? " open" : ""}`}>
        <div style={{ padding: "18px 16px 13px", borderBottom: "1px solid var(--bd)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: "var(--gs)", border: "1px solid rgba(58,125,92,.2)", display: "flex", alignItems: "center", justifyContent: "center" }}><I n="leaf" s={17} c="var(--g)" /></div>
            <div><div style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 19, color: "var(--ink)", lineHeight: 1.1 }}>Lumis</div><div style={{ fontSize: 9.5, color: "var(--mu)", letterSpacing: ".7px" }}>PERSONAL AI</div></div>
          </div>
          <button onClick={() => setSbOpen(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--mu)", padding: 6, borderRadius: 8 }}><I n="x" s={18} /></button>
        </div>
        <nav style={{ flex: 1, overflowY: "auto", padding: "8px 10px" }}>
          {[...nav, { id: "memory", i: "brain", l: "Memory" }].map(x => (
            <div key={x.id} className={`ni${view === x.id ? " on" : ""}`} onClick={() => { setView(x.id); setSbOpen(false); }}><I n={x.i} s={15} c={view === x.id ? "var(--g)" : "var(--mu)"} />{x.l}</div>
          ))}
        </nav>
        <div style={{ padding: "12px 14px", borderTop: "1px solid var(--bd)" }}>
          <div style={{ fontSize: 12, color: "var(--mu)", marginBottom: 6 }}>👤 Pratik Pandey</div>
          <button onClick={() => setLocked(true)} className="btn-o" style={{ width: "100%", justifyContent: "center", fontSize: 12, padding: "8px" }}><I n="lock" s={13} />Lock</button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", position: "relative", zIndex: 1, minHeight: 0 }}>
        {view === "home" && (
          <div className="topbar">
            <button onClick={() => setSbOpen(true)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--ink)", padding: 8, borderRadius: 8, touchAction: "manipulation" }}><I n="menu" s={21} /></button>
            <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 20, color: "var(--ink)", flex: 1 }}>Lumis</span>
            <div style={{ display: "flex", alignItems: "center", gap: 5 }}><div style={{ width: 7, height: 7, borderRadius: 99, background: "var(--g)" }} /><span style={{ fontSize: 11, color: "var(--mu)" }}>AI</span></div>
          </div>
        )}
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column", minHeight: 0 }}>
          {panel()}
        </div>
      </div>

      {/* Bottom Nav */}
      <div className="bnav" style={{ position: "relative", zIndex: 1 }}>
        {nav.map(x => (
          <div key={x.id} className={`bni${view === x.id ? " on" : ""}`} onClick={() => setView(x.id)}>
            <I n={x.i} s={20} c={view === x.id ? "var(--g)" : "var(--mu)"} />
            <span>{x.l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
