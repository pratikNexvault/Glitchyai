import LumisApp from "@/components/LumisApp";
export default function Page() { return <LumisApp />; }
