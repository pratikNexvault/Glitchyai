import type { Metadata } from "next";
export const metadata: Metadata = { title: "Lumis", description: "Personal AI" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Cormorant+Garamond:wght@300;400;500;600&display=swap" rel="stylesheet"/>
      </head>
      <body style={{margin:0,padding:0,background:"#f0f4f1",fontFamily:"Outfit,sans-serif"}}>{children}</body>
    </html>
  );
}
