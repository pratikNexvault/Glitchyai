// src/app/api/telegram/webhook/route.ts
import { NextRequest, NextResponse } from "next/server";
import { askLumis, sendEmail } from "@/lib/brain";

// In-memory conversation history per chat (resets on redeploy — use MongoDB for persistent)
const chatHistory: Record<number, { role: string; content: string }[]> = {};

export async function POST(req: NextRequest) {
  try {
    const update = await req.json();
    const msg = update.message;
    if (!msg?.text && !msg?.photo) return NextResponse.json({ ok: true });

    const chatId = msg.chat.id;
    const text = msg.text || "";
    const userId = msg.from?.id;

    // Security: only owner can use
    const ownerId = parseInt(process.env.TELEGRAM_OWNER_ID || "0");
    if (ownerId && userId !== ownerId) {
      await tgSend(chatId, "🔒 Private bot. Access denied.");
      return NextResponse.json({ ok: true });
    }

    // Init history
    if (!chatHistory[chatId]) chatHistory[chatId] = [];

    // Commands
    if (text === "/start") {
      await tgSend(chatId, `🌿 *Welcome to Lumis AI!*\n\nSame AI as the website — ask me anything!\n\n/clear — Reset conversation\n/status — Check systems\n\nJust type anything to start!`);
      return NextResponse.json({ ok: true });
    }

    if (text === "/clear") {
      chatHistory[chatId] = [];
      await tgSend(chatId, "🗑️ Conversation cleared!");
      return NextResponse.json({ ok: true });
    }

    if (text === "/status") {
      await tgSend(chatId, `*Lumis Status:*\n\n✅ AI Brain: Active\n✅ Telegram: Connected\n${process.env.GMAIL_USER ? "✅" : "❌"} Gmail: ${process.env.GMAIL_USER ? "Ready" : "Not configured"}\n${process.env.MONGODB_URI ? "✅" : "⚠️"} MongoDB: ${process.env.MONGODB_URI ? "Connected" : "Not configured"}`);
      return NextResponse.json({ ok: true });
    }

    // Regular message
    await tgTyping(chatId);
    chatHistory[chatId].push({ role: "user", content: text });
    if (chatHistory[chatId].length > 20) chatHistory[chatId] = chatHistory[chatId].slice(-20);

    const reply = await askLumis(chatHistory[chatId], `tg_${chatId}`, "telegram");
    chatHistory[chatId].push({ role: "assistant", content: reply });

    // Execute email actions from bot too
    const emailMatches = [...reply.matchAll(/```email_action\n?([\s\S]*?)```/g)];
    for (const m of emailMatches) {
      try {
        const d = JSON.parse(m[1].trim());
        await sendEmail(d.to, d.subject, d.body);
      } catch {}
    }

    // Clean reply for Telegram (remove action blocks)
    const cleanReply = reply
      .replace(/```email_action[\s\S]*?```/g, "📧 _Email sent!_")
      .replace(/```tg_action[\s\S]*?```/g, "")
      .replace(/```file_action:[^\n]+\n[\s\S]*?```/g, "📄 _File created (check website)_")
      .replace(/```mem_action[\s\S]*?```/g, "🧠 _Saved to memory_")
      .trim();

    // Split long messages
    if (cleanReply.length > 4000) {
      const chunks = cleanReply.match(/.{1,4000}/gs) || [cleanReply];
      for (const chunk of chunks) {
        await tgSend(chatId, chunk);
      }
    } else {
      await tgSend(chatId, cleanReply);
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error("Telegram webhook error:", e);
    return NextResponse.json({ ok: true }); // Always 200 to Telegram
  }
}

// Register webhook — GET /api/telegram/webhook?secret=yourpassword
export async function GET(req: NextRequest) {
  const secret = req.nextUrl.searchParams.get("secret");
  if (secret !== process.env.APP_PASSWORD) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!appUrl || !token) return NextResponse.json({ error: "Missing NEXT_PUBLIC_APP_URL or TELEGRAM_BOT_TOKEN" }, { status: 400 });

  const webhookUrl = `${appUrl}/api/telegram/webhook`;
  const res = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: webhookUrl, allowed_updates: ["message","callback_query"] }),
  });
  const d = await res.json();
  return NextResponse.json({ webhook_url: webhookUrl, telegram: d });
}

// Helper functions
async function tgSend(chatId: number, text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN!;
  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "Markdown" }),
  });
}

async function tgTyping(chatId: number) {
  const token = process.env.TELEGRAM_BOT_TOKEN!;
  await fetch(`https://api.telegram.org/bot${token}/sendChatAction`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, action: "typing" }),
  });
}
