// src/app/api/ai/route.ts
import { NextRequest, NextResponse } from "next/server";
import { askLumis, askLumisWithImage, sendToTelegram, sendEmail } from "@/lib/brain";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages, sessionId, imageBase64, imageMime } = body;

    let reply: string;

    if (imageBase64) {
      // Image + text call
      const lastMsg = messages[messages.length - 1];
      const history = messages.slice(0, -1).map((m: any) => ({ role: m.role, content: m.content }));
      reply = await askLumisWithImage(lastMsg.content || "", imageBase64, imageMime || "image/jpeg", history, sessionId || "web");
    } else {
      reply = await askLumis(messages, sessionId || "web", "web");
    }

    // Parse and execute actions server-side
    const actions: any = {};

    // Email actions
    const emailMatches = [...reply.matchAll(/```email_action\n?([\s\S]*?)```/g)];
    for (const m of emailMatches) {
      try {
        const d = JSON.parse(m[1].trim());
        const result = await sendEmail(d.to, d.subject, d.body);
        actions.email = { to: d.to, result };
      } catch {}
    }

    // Telegram actions
    const tgMatches = [...reply.matchAll(/```tg_action\n?([\s\S]*?)```/g)];
    for (const m of tgMatches) {
      try {
        const d = JSON.parse(m[1].trim());
        const ok = await sendToTelegram(d.msg);
        actions.telegram = { sent: ok, msg: d.msg.slice(0, 50) };
      } catch {}
    }

    return NextResponse.json({ reply, actions });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
