// src/app/api/train/route.ts
// Lumis self-trains automatically — runs via Vercel Cron every 6 hours

import { NextRequest, NextResponse } from "next/server";
import { connectDB, Train, TrainLog } from "@/lib/db";
import { askLumis, webSearch } from "@/lib/brain";

// Topics Lumis auto-studies to improve itself
const STUDY_TOPICS = [
  "Python best practices 2024",
  "TypeScript advanced patterns",
  "React hooks performance optimization",
  "Next.js 14 app router best practices",
  "FastAPI production deployment",
  "MongoDB aggregation pipeline",
  "Telegram bot grammy.js advanced",
  "REST API design principles",
  "Node.js async patterns",
  "Docker containerization tips",
  "JWT authentication security",
  "CSS modern layout flexbox grid",
  "Git workflow strategies",
  "PostgreSQL performance tuning",
  "AI prompt engineering techniques",
  "WebSocket real-time applications",
  "Redis caching strategies",
  "GraphQL schema design",
  "Microservices architecture patterns",
  "CI/CD pipeline GitHub Actions",
];

export async function GET(req: NextRequest) {
  // Verify cron secret
  const auth = req.headers.get("authorization");
  const secret = process.env.CRON_SECRET || process.env.APP_PASSWORD || "lumis2024";
  if (auth !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const dbOk = await connectDB();
  if (!dbOk) return NextResponse.json({ error: "MongoDB not configured" }, { status: 400 });

  const start = Date.now();
  let added = 0;

  // Phase 1: Learn from web search
  const topic = STUDY_TOPICS[Math.floor(Math.random() * STUDY_TOPICS.length)];
  const searchResults = await webSearch(topic);

  for (const result of searchResults.slice(0, 3)) {
    try {
      // Ask AI to synthesize this knowledge
      const synthesis = await askLumis([{
        role: "user",
        content: `Study this and create a high-quality Q&A training example about: "${topic}"\n\nSource: ${result.snippet}\n\nFormat: write a realistic user question and your ideal detailed answer.`
      }], "auto_train", "web");

      // Parse and save
      await Train.create({
        input: `Tell me about ${topic}`,
        output: synthesis.slice(0, 1500),
        quality: 8,
        source: "auto_web_study",
        tags: topic.toLowerCase().split(" "),
      });
      added++;
    } catch {}
  }

  // Phase 2: Extract training from recent conversations
  const { Msg } = await import("@/lib/db");
  const recentMsgs = await Msg.find({ role: "user", createdAt: { $gt: new Date(Date.now() - 86400000) } }).limit(20);

  for (const userMsg of recentMsgs) {
    const existing = await Train.findOne({ input: userMsg.content?.slice(0, 50) });
    if (!existing && userMsg.content?.length > 15) {
      // Get corresponding AI reply
      const aiMsg = await Msg.findOne({ sessionId: userMsg.sessionId, role: "assistant", createdAt: { $gt: userMsg.createdAt } }).sort({ createdAt: 1 });
      if (aiMsg?.content && aiMsg.content.length > 50) {
        await Train.create({
          input: userMsg.content,
          output: aiMsg.content.slice(0, 1000),
          quality: 8,
          source: "conversation_extraction",
          tags: ["conversation"],
        });
        added++;
      }
    }
  }

  // Log training run
  await TrainLog.create({ topic, added, duration: Date.now() - start });

  return NextResponse.json({
    ok: true, topic, added,
    duration: `${Date.now() - start}ms`,
    timestamp: new Date().toISOString(),
  });
}
