// src/app/api/memory/route.ts
import { NextRequest, NextResponse } from "next/server";
import { connectDB, Mem } from "@/lib/db";

export async function GET() {
  await connectDB();
  try {
    const mems = await Mem.find().sort({ importance: -1, createdAt: -1 }).limit(100);
    return NextResponse.json({ mems });
  } catch {
    return NextResponse.json({ mems: [] });
  }
}

export async function POST(req: NextRequest) {
  await connectDB();
  const { text, type, importance } = await req.json();
  try {
    const mem = await Mem.create({ text, type: type || "fact", importance: importance || 5 });
    return NextResponse.json({ ok: true, mem });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  await connectDB();
  const { id } = await req.json();
  try {
    await Mem.findByIdAndDelete(id);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
