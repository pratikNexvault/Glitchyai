// src/lib/db.ts
import mongoose, { Schema, model, models } from "mongoose";

let connected = false;

export async function connectDB() {
  if (connected || !process.env.MONGODB_URI) return false;
  try {
    await mongoose.connect(process.env.MONGODB_URI!);
    connected = true;
    return true;
  } catch { return false; }
}

/* ── Conversation (all messages saved for training) ── */
const MsgSchema = new Schema({
  sessionId: String,
  source: { type: String, enum: ["web","telegram"], default: "web" },
  role: { type: String, enum: ["user","assistant"] },
  content: String,
  hasImage: Boolean,
  createdAt: { type: Date, default: Date.now },
});
export const Msg = models.Msg || model("Msg", MsgSchema);

/* ── Training Data — Lumis learns from every interaction ── */
const TrainSchema = new Schema({
  input: String,
  output: String,
  quality: { type: Number, default: 7 }, // 1-10
  source: String, // "conversation","web_search","manual"
  tags: [String],
  usedAt: Date,
  createdAt: { type: Date, default: Date.now },
});
export const Train = models.Train || model("Train", TrainSchema);

/* ── Memory — things Lumis remembers about owner ── */
const MemSchema = new Schema({
  text: String,
  type: { type: String, enum: ["fact","preference","instruction","task"], default: "fact" },
  importance: { type: Number, default: 5 },
  createdAt: { type: Date, default: Date.now },
});
export const Mem = models.Mem || model("Mem", MemSchema);

/* ── Self-train log ── */
const TrainLogSchema = new Schema({
  topic: String, added: Number, duration: Number,
  createdAt: { type: Date, default: Date.now },
});
export const TrainLog = models.TrainLog || model("TrainLog", TrainLogSchema);
