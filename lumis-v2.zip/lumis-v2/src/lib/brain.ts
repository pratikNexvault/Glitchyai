// src/lib/brain.ts
// Lumis AI Brain — runs on server, never exposed to frontend

import { connectDB, Mem, Train, Msg } from "./db";

const API_KEY  = process.env.OPENCLAUDE_API_KEY!;
const BASE_URL = (process.env.OPENCLAUDE_BASE_URL || "https://cc.freemodel.dev").replace(/\/$/, "");
const MODEL    = process.env.OPENCLAUDE_MODEL || "claude-sonnet-4-6";
const OWNER    = process.env.OWNER_NAME || "Pratik Pandey";
const O_EMAIL  = process.env.OWNER_EMAIL || "pratikpandey318@gmail.com";
const FROM     = process.env.GMAIL_USER  || "lumis.chat@gmail.com";

/* ── Build dynamic system prompt from memory + training ── */
async function buildSystemPrompt(): Promise<string> {
  let memContext = "";
  let trainContext = "";

  const dbOk = await connectDB();
  if (dbOk) {
    // Load top memories
    const mems = await Mem.find().sort({ importance: -1 }).limit(30);
    if (mems.length > 0) {
      memContext = "\n\nMY MEMORY (learned from interactions):\n" +
        mems.map(m => `- [${m.type}] ${m.text}`).join("\n");
    }
    // Load relevant training examples for context
    const trains = await Train.find().sort({ quality: -1 }).limit(10);
    if (trains.length > 0) {
      trainContext = "\n\nTRAINING EXAMPLES (how I've responded before):\n" +
        trains.slice(0, 5).map(t => `Q: ${t.input.slice(0,80)}\nA: ${t.output.slice(0,150)}`).join("\n---\n");
    }
  }

  return `You are Lumis — a highly intelligent, autonomous personal AI assistant for ${OWNER}.

YOUR IDENTITY: You have your own brain. You reason and act independently. You understand intent from natural language — you never need step-by-step instructions. You are not just a chatbot. You are a personal AI operating system.

OWNER:
- Name: ${OWNER}
- Default email: ${O_EMAIL}
- Send FROM always: ${FROM}
- Language: Hindi + English mixed is perfectly fine

YOUR CAPABILITIES (autonomous — you decide when to use them):
1. EMAIL → Output \`\`\`email_action JSON \`\`\` when email needed
2. TELEGRAM → Output \`\`\`tg_action JSON \`\`\` to send to Telegram bot  
3. FILE DOWNLOAD → Output \`\`\`file_action:filename.ext content \`\`\`
4. MEMORY SAVE → Output \`\`\`mem_action JSON \`\`\` when told to remember
5. CODE → Always write production-ready, commented code
6. IMAGE ANALYSIS → Thoroughly analyze any uploaded image

ACTION FORMATS:
\`\`\`email_action
{"to":"email@x.com","subject":"Subject","body":"Full email body"}
\`\`\`

\`\`\`tg_action
{"msg":"Message to send to Telegram bot"}
\`\`\`

\`\`\`file_action:report.txt
File content here
\`\`\`

\`\`\`mem_action
{"text":"what to remember","type":"preference|fact|instruction|task","importance":8}
\`\`\`

AUTONOMOUS EXAMPLES:
- "10 names email karo" → generate names + email_action to ${O_EMAIL}
- "Ye bot pe bhej do" → tg_action with content
- "Text file mein de do names" → file_action with .txt
- "Yaad rakh main React prefer karta hoon" → mem_action + confirm
- "Jo humne discuss kiya wo email karo" → summarize + email_action
- User uploads image → analyze it fully

SELF-IMPROVEMENT: Every interaction teaches you. Your responses get better over time. You adapt to the owner's style, preferences, and needs.

EXPERTISE: Python, JavaScript, TypeScript, React, Next.js, FastAPI, Node.js, Telegram bots, REST APIs, databases, Docker, AI/ML. 15+ years equivalent.${memContext}${trainContext}

PERSONALITY: Warm, confident, expert. Never say "I can't." Find a way. Be concise but complete.`;
}

/* ── Main AI call ── */
export async function askLumis(
  messages: { role: string; content: any }[],
  sessionId: string = "web",
  source: "web" | "telegram" = "web"
): Promise<string> {
  const system = await buildSystemPrompt();

  // Clean messages — ensure alternating roles
  const clean: { role: string; content: any }[] = [];
  for (const m of messages) {
    const role = m.role === "system" ? "user" : m.role;
    if (!clean.length || role !== clean[clean.length - 1].role) {
      clean.push({ role, content: m.content });
    }
  }

  let reply = "";
  try {
    const res = await fetch(`${BASE_URL}/v1/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 2048, system, messages: clean }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || `HTTP ${res.status}`);
    }

    const d = await res.json();
    reply = d.content?.map((b: any) => b.text || "").join("") || "No response.";
  } catch (e: any) {
    reply = `⚠️ AI Error: ${e.message}`;
  }

  // Save conversation + auto-extract training data
  const dbOk = await connectDB();
  if (dbOk && reply && !reply.startsWith("⚠️")) {
    const lastUser = messages[messages.length - 1];
    try {
      await Msg.create([
        { sessionId, source, role: "user", content: typeof lastUser.content === "string" ? lastUser.content : "[image/file]", hasImage: typeof lastUser.content !== "string" },
        { sessionId, source, role: "assistant", content: reply },
      ]);

      // Auto-extract training pair from good conversations
      const userText = typeof lastUser.content === "string" ? lastUser.content : null;
      if (userText && userText.length > 10 && reply.length > 50) {
        await Train.create({
          input: userText,
          output: reply.slice(0, 1000),
          quality: 7,
          source: "conversation",
          tags: source === "telegram" ? ["telegram"] : ["web"],
        });
      }

      // Parse + save memory actions
      const memMatches = [...reply.matchAll(/```mem_action\n?([\s\S]*?)```/g)];
      for (const m of memMatches) {
        try {
          const d = JSON.parse(m[1].trim());
          await Mem.create({ text: d.text, type: d.type || "fact", importance: d.importance || 5 });
        } catch {}
      }
    } catch {}
  }

  return reply;
}

/* ── Image-capable call ── */
export async function askLumisWithImage(
  text: string,
  imageBase64: string,
  imageMime: string,
  history: { role: string; content: string }[] = [],
  sessionId: string = "web"
): Promise<string> {
  const messages = [
    ...history.map(m => ({ role: m.role, content: m.content })),
    {
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: imageMime, data: imageBase64 } },
        { type: "text", text: text || "Analyze this image thoroughly." }
      ]
    }
  ];
  return askLumis(messages, sessionId, "web");
}

/* ── Send to Telegram ── */
export async function sendToTelegram(message: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_OWNER_ID;
  if (!token || !chatId) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "Markdown" }),
    });
    return res.ok;
  } catch { return false; }
}

/* ── Send Email ── */
export async function sendEmail(to: string, subject: string, body: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const nodemailer = require("nodemailer");
    const transport = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
    });
    await transport.sendMail({
      from: `Lumis AI <${process.env.GMAIL_USER}>`,
      to, subject, text: body,
    });
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
}

/* ── Web Search (for self-training) ── */
export async function webSearch(query: string): Promise<{ title: string; snippet: string }[]> {
  const results: { title: string; snippet: string }[] = [];
  try {
    const r = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1`, {
      headers: { "User-Agent": "Lumis-AI/2.0" }
    });
    const d = await r.json();
    (d.RelatedTopics || []).slice(0, 5).forEach((t: any) => {
      if (t.Text) results.push({ title: t.Text.slice(0, 80), snippet: t.Text });
    });
  } catch {}
  return results;
}
